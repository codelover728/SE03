package com.example.myapplication;

import static java.lang.Math.min;
import static java.lang.StrictMath.max;


class ThelargestSubSegmentAnd {
	private long n;
	private long[] nums;

	ThelargestSubSegmentAnd(long n, long[] nums) {
		this.n = n;
		this.nums = nums;
	}
	long Solve()
	{
		long sum=0;//计算n个元素的和
		long s=0;//最大子段和
		long mins=0;//记录从第一个元素开始到当前元素的最小连续和
		for (int i=0;i<n;++i)
		{
			sum+=nums[i];
			s=max(sum-mins,s);
			mins=min(sum,mins);
		}
		return s;
	}
}
