package com.example.myapplication;

import org.junit.Test;

import static org.junit.Assert.*;

/**
 * Created by 王松 on 2018/3/26.
 */
public class ThelargestSubSegmentAndTest {
	@Test
	public void solve() throws Exception {
		assertEquals(20,new ThelargestSubSegmentAnd(6,new long[]{-2 ,11 ,-4 ,13 ,-5 ,-2}).Solve());
		assertEquals(10,new ThelargestSubSegmentAnd(10,new long[]{-10,1,2,3,4,-5,-23,3,7,-21}).Solve());
		assertEquals(10,new ThelargestSubSegmentAnd(6,new long[]{5 ,-8 ,3 ,2 ,5, 0}).Solve());
		assertEquals(10,new ThelargestSubSegmentAnd(1,new long[]{10}).Solve());
		assertEquals(0,new ThelargestSubSegmentAnd(3,new long[]{-1,-5,-2}).Solve());
		assertEquals(0,new ThelargestSubSegmentAnd(3,new long[]{-1,0,-2}).Solve());
	}

}